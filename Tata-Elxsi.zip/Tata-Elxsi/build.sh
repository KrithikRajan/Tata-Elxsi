mkdir build
cd build
cmake ..
make