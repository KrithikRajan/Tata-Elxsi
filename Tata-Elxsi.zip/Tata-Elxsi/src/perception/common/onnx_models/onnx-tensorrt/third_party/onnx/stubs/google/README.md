Type stubs taken from https://github.com/python/typeshed/tree/f4d19d9f612ae24dfe3e35770d7820c3bd4045d2/third_party/2/google
Which unfortunately only defines it for python 2, but we also need it for python 3.

This stub can be deleted once we updated to a mypy version including https://github.com/python/typeshed/pull/2140
