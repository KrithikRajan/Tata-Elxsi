./build/bin/build_tensorrt_engine -i models/object_detection/ctdet_coco_resdcn18.onnx \
        -o models/object_detection/ctdet_coco_resdcn18.engine -m 1